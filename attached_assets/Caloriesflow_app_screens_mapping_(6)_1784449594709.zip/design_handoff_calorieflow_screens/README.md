# Handoff: CalorieFlow — Mobile Screens + Forgot-Password Flow

## Overview
Hi-fi mobile mockups of the CalorieFlow calorie-tracking app: all 6 existing screens (Auth, Dashboard, Log Meal AI chat, Progress, Recipes + detail, Settings), the logout modal, and a **new 3-step forgot-password flow with email verification** (the main net-new feature to implement).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the existing CaloriesFlow codebase** (React + TypeScript, Vite, Wouter, TanStack Query v5, Shadcn/UI, Tailwind CSS — repo `Pauzenk/CaloriesFlow`), following its established patterns. The existing screens (1a–1h) are recreations of code already in the repo and need no work; they exist for visual context. **The new work is the forgot-password flow (screens 2a–2c).**

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy match the app's existing design language exactly. Recreate pixel-perfectly using the codebase's existing Tailwind utilities and Shadcn components.

## Screens / Views

### 2a — Forgot Password (request)
- **Route**: `/forgot-password`, linked from AuthPage login tab ("Forgot password?" link should be added under the password field).
- **Layout**: full-screen linen background `#F2EDE7`, vertically centered white card (`bg-white`, `border border-[#D4CFC8]`, `p-6`, max-w-sm, no border radius — the whole app is `--radius: 0`).
- **Components**:
  - "← Back to log in" link: 11px uppercase, `tracking-[2px]`, color `#6B6560`, arrow-left icon (lucide `ArrowLeft`, 13px).
  - Brand row: 36×36 `#3c3a40` square with white lucide `Leaf` icon (16px) + "CalorieFlow" 20px bold, `tracking-tight`.
  - Title "Forgot password?" 22px bold `#1C1714`; subtitle 13px `#6B6560`: "Enter your account email and we'll send you a verification code."
  - Email field: label 11px bold uppercase `tracking-wider` `#6B6560`; input `border-[#D4CFC8] bg-[#FAF8F6]` h-38px, 13px text.
  - Primary button "Send code": h-44px, `bg-[#3c3a40]` white 13px bold, hover `bg-[#2d2b30]`.
  - Footer: "Remembered it? Log in" — 11px `#6B6560`, link underlined `#3c3a40` bold.

### 2b — Check Your Email (code entry)
- **Route**: `/forgot-password/verify` (or same page, step state).
- Same card shell as 2a.
- **Components**:
  - "← Back" link (same style).
  - 44×44 bordered square (`border-[#1C1714]/20`) with lucide `Mail` icon 18px at 60% opacity.
  - Title "Check your email" 22px bold; subtitle 13px `#6B6560`: "We sent a 6-digit code to **anna@example.com**. It expires in 10 minutes." (email in `#1C1714` bold).
  - **Code input**: 6 equal boxes, `flex gap-1.5`, each flex-1 × 48px tall, `bg-[#FAF8F6]`, centered 20px bold digit.
    - Filled boxes: `border border-[#1C1714]`.
    - Active box: `border-2 border-[#3c3a40]` with blinking text caret.
    - Empty boxes: `border border-[#D4CFC8]`.
  - Primary button "Verify code" (same as Send code).
  - Footer: "Didn't get it? Resend (0:42)" — Resend underlined `#3c3a40` bold; countdown timer disables Resend until 0:00.

### 2c — Set New Password
- **Route**: `/forgot-password/reset` (requires verified code).
- Same card shell.
- **Components**:
  - Success banner: `border border-[#1C1714]/20 bg-[#F5F1EB]` px-3 py-2.5, 11px, lucide `Check` icon 13px: "Email verified — anna@example.com".
  - Title "Set a new password" 22px bold; subtitle 13px `#6B6560`: "Minimum 6 characters."
  - Two password fields ("New password", "Confirm password") — same input style as 2a.
  - Primary button "Reset password".
  - Footer note 11px `#6B6560` centered: "You'll be signed in automatically."

### 1a–1h — Existing screens (context only)
Auth (`/login`), Dashboard (`/`), Log Meal chat (`/log`, dark `#1C1714` theme), Progress (`/progress`), Recipes (`/recipes`) + full-screen recipe detail overlay, Settings (`/settings`), logout confirmation modal. These already exist in the repo (`client/src/pages/*`) — no implementation needed.

## Interactions & Behavior
- 2a "Send code" → POST request → navigate to 2b. Show inline error under email field on unknown address (or always claim success to avoid enumeration — backend choice).
- 2b: auto-advance focus per digit; paste fills all 6; "Verify code" disabled until 6 digits; wrong code → boxes get `border-[#9B4A2E]` + 12px terracotta error line; Resend disabled during countdown (60s), timer shown in parentheses.
- 2c: validate min 6 chars + match; on success sign the user in and redirect to `/` (Dashboard).
- All buttons: no border radius, color-only hover transitions (`transition-colors`), min touch target 44px.

## State Management
- `step: "request" | "verify" | "reset"`, `email: string`, `code: string[6]`, `resendSecondsLeft: number`, mutation states via TanStack Query (`useMutation`), toasts via existing `use-toast` hook.
- Backend needs: `POST /api/auth/forgot-password` (send code email), `POST /api/auth/verify-code`, `POST /api/auth/reset-password` (returns session).

## Design Tokens
- Background linen: `#F2EDE7`; card white: `#FFFFFF`; input bg: `#FAF8F6`; subtle bg: `#F5F1EB`
- Ink: `#1C1714`; muted text: `#6B6560`; border: `#D4CFC8`
- Brand dark: `#3c3a40` (hover `#2d2b30`); terracotta/destructive: `#9B4A2E` / `#9e4515`
- Font: **Space Mono** (400/700), monospace. Labels: 10–11px uppercase, letter-spacing 1.5–2px
- Border radius: **0 everywhere**
- Touch targets ≥ 44px

## Assets
- `logo.png` — app logo (from repo `client/public/logo.png`)
- Icons: lucide-react (`ArrowLeft`, `Mail`, `Check`, `Leaf`) — already a repo dependency

## Files
- `index.html` — all mockups on one canvas (2a–2c = forgot-password flow; 1a–1h = existing screens)
- `ios-frame.jsx`, `support.js` — mockup viewer scaffolding, ignore for implementation
- `logo.png`
